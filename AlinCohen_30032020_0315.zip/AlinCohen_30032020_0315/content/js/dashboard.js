/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.1212290502793296, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "HTTP Request-Store"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Blog-Fashion"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-About-Pres"], "isController": false}, {"data": [0.29, 500, 1500, "HTTP Request-Store-Accessories-0"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-Accessories-1"], "isController": false}, {"data": [0.01, 500, 1500, "HTTP Request-About-Pres-1"], "isController": false}, {"data": [0.25, 500, 1500, "HTTP Request-About-Pres-0"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-1"], "isController": false}, {"data": [0.23, 500, 1500, "HTTP Request-Store-Lips-0"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Blog"], "isController": false}, {"data": [0.26, 500, 1500, "HTTP Request-Store-0"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-Lips-1"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request--Youtube"], "isController": false}, {"data": [0.0, 500, 1500, "88.202.218.154 Swap"], "isController": false}, {"data": [0.022727272727272728, 500, 1500, "HTTP Request-Blog-Beauty-1"], "isController": false}, {"data": [0.46296296296296297, 500, 1500, "HTTP Request-Blog-LifeStyle-0"], "isController": false}, {"data": [0.3977272727272727, 500, 1500, "HTTP Request-Blog-Beauty-0"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-Accessories"], "isController": false}, {"data": [0.09259259259259259, 500, 1500, "HTTP Request-Blog-LifeStyle-1"], "isController": false}, {"data": [0.38, 500, 1500, "HTTP Request-Blog-Fashion-0"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Blog-Fashion-1"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Contact"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Website-1"], "isController": false}, {"data": [0.32, 500, 1500, "HTTP Request-Website-0"], "isController": false}, {"data": [0.16666666666666666, 500, 1500, "HTTP Request-Contact-0"], "isController": false}, {"data": [0.0, 500, 1500, "88.202.218.154 TCP"], "isController": false}, {"data": [0.02, 500, 1500, "HTTP Request-About-1"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Contact-1"], "isController": false}, {"data": [0.006711409395973154, 500, 1500, "88.202.218.154 Network I\/O"], "isController": false}, {"data": [0.19, 500, 1500, "HTTP Request-About-0"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-Eyes&Brows"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Website"], "isController": false}, {"data": [0.28, 500, 1500, "HTTP Request-Blog-0"], "isController": false}, {"data": [0.0, 500, 1500, "88.202.218.154 CPU"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-Lips"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request--Youtube-1"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Blog-1"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Blog-Beauty"], "isController": false}, {"data": [0.0, 500, 1500, "88.202.218.154 Memory"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-Face"], "isController": false}, {"data": [0.425, 500, 1500, "HTTP Request--Youtube-0"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-About"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-Eyes&Brows-1"], "isController": false}, {"data": [0.0, 500, 1500, "HTTP Request-Store-Face-1"], "isController": false}, {"data": [0.18, 500, 1500, "HTTP Request-Store-Eyes&Brows-0"], "isController": false}, {"data": [0.25, 500, 1500, "HTTP Request-Store-Face-0"], "isController": false}, {"data": [0.05555555555555555, 500, 1500, "HTTP Request-Blog-LifeStyle"], "isController": false}, {"data": [0.9865771812080537, 500, 1500, "88.202.218.154 Disks I\/O"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2685, 0, 0.0, 6.870296211387725E15, 0, 9223372036854775807, 1.2536800000000004E7, 8.388608E9, 8.388608E9, 3.2007109397682134E-4, 0.0074689765087104735, 4.60847242037623E-5], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["HTTP Request-Store", 50, 0, 0.0, 8760.220000000001, 3217, 15647, 12965.9, 14798.849999999999, 15647.0, 0.7694912124103542, 68.40803930753486, 0.2479805664994306], "isController": false}, {"data": ["HTTP Request-Blog-Fashion", 50, 0, 0.0, 8226.439999999997, 3811, 15863, 14511.599999999999, 15398.099999999999, 15863.0, 0.5862626925872946, 30.139284107297797, 0.19923771193396336], "isController": false}, {"data": ["HTTP Request-About-Pres", 50, 0, 0.0, 9390.120000000003, 4516, 16235, 15264.2, 15714.699999999999, 16235.0, 0.5308531872425363, 23.2751024712543, 0.16692844364462564], "isController": false}, {"data": ["HTTP Request-Store-Accessories-0", 50, 0, 0.0, 1750.4199999999998, 167, 3798, 3313.1, 3796.9, 3798.0, 0.5805110819565545, 0.33730868531655267, 0.09807462615086322], "isController": false}, {"data": ["HTTP Request-Store-Accessories-1", 50, 0, 0.0, 7647.620000000001, 3316, 12518, 11722.8, 12366.3, 12518.0, 0.5461675423552929, 20.154329026347124, 0.09227244612057195], "isController": false}, {"data": ["HTTP Request-About-Pres-1", 50, 0, 0.0, 7108.62, 1298, 12803, 11926.699999999999, 12478.35, 12803.0, 0.5493539597433418, 23.782080125335103, 0.08637303468620901], "isController": false}, {"data": ["HTTP Request-About-Pres-0", 50, 0, 0.0, 2281.2200000000007, 317, 6849, 4722.0, 6306.649999999996, 6849.0, 0.5566441040256502, 0.30821992869389025, 0.08751923901184538], "isController": false}, {"data": ["HTTP Request-Store-1", 50, 0, 0.0, 6599.82, 1994, 11807, 9649.5, 10865.249999999998, 11807.0, 0.8029806642256054, 70.93437088472409, 0.12938653280978993], "isController": false}, {"data": ["HTTP Request-Store-Lips-0", 50, 0, 0.0, 2201.7000000000003, 298, 5923, 4601.8, 5370.399999999998, 5923.0, 0.797804442175134, 0.46356801083418436, 0.1347853207971662], "isController": false}, {"data": ["HTTP Request-Blog", 50, 0, 0.0, 8367.760000000002, 3748, 14449, 11610.5, 13539.0, 14449.0, 0.5588590333974158, 30.479647751151248, 0.18665018498234004], "isController": false}, {"data": ["HTTP Request-Store-0", 50, 0, 0.0, 2160.1399999999994, 153, 4037, 3900.3, 4000.9, 4037.0, 0.9344571738277234, 0.5247196044442783, 0.15057171257966248], "isController": false}, {"data": ["HTTP Request-Store-Lips-1", 50, 0, 0.0, 6266.78, 1748, 11889, 11491.6, 11822.85, 11889.0, 0.7095519888742248, 38.15227783927229, 0.11987548249535243], "isController": false}, {"data": ["HTTP Request--Youtube", 20, 0, 0.0, 11997.2, 3973, 23811, 20903.40000000001, 23682.8, 23811.0, 0.28998956037582646, 47.28347748231064, 0.09515282449831805], "isController": false}, {"data": ["88.202.218.154 Swap", 149, 0, 0.0, 8.388608E9, 8388608000, 8388608000, 8.388608E9, 8.388608E9, 8.388608E9, 1.7761859593382285E-5, 0.0, 0.0], "isController": false}, {"data": ["HTTP Request-Blog-Beauty-1", 44, 0, 0.0, 4863.181818181818, 1072, 12286, 10555.5, 12107.25, 12286.0, 0.5751408441499025, 20.15801259427735, 0.09772901062703424], "isController": false}, {"data": ["HTTP Request-Blog-LifeStyle-0", 27, 0, 0.0, 1611.5925925925928, 119, 4459, 3967.9999999999995, 4389.0, 4459.0, 0.3963477290743078, 0.23104515152960864, 0.06734814927629841], "isController": false}, {"data": ["HTTP Request-Blog-Beauty-0", 44, 0, 0.0, 1327.9545454545455, 312, 4138, 2106.0, 2726.75, 4138.0, 0.580283547642598, 0.3383098417408506, 0.09860286844708209], "isController": false}, {"data": ["HTTP Request-Store-Accessories", 50, 0, 0.0, 9398.36, 5086, 13806, 13109.3, 13501.95, 13806.0, 0.5358080521234073, 20.083383453711544, 0.18104451761201068], "isController": false}, {"data": ["HTTP Request-Blog-LifeStyle-1", 27, 0, 0.0, 3870.7777777777783, 645, 11688, 7687.399999999997, 11459.599999999999, 11688.0, 0.38533995547182737, 13.169252213028772, 0.06547768774618942], "isController": false}, {"data": ["HTTP Request-Blog-Fashion-0", 50, 0, 0.0, 1463.7800000000002, 390, 6529, 3257.5999999999995, 3767.099999999998, 6529.0, 0.6124073733847756, 0.3570382831159287, 0.10406140914936617], "isController": false}, {"data": ["HTTP Request-Blog-Fashion-1", 50, 0, 0.0, 6762.420000000002, 2221, 12887, 11843.4, 12115.0, 12887.0, 0.6072751563733527, 30.86547147324953, 0.10318933321187831], "isController": false}, {"data": ["HTTP Request-Contact", 6, 0, 0.0, 9480.5, 3724, 13009, 13009.0, 13009.0, 13009.0, 0.11811023622047244, 4.30423766609252, 0.03667876476377953], "isController": false}, {"data": ["HTTP Request-Website-1", 50, 0, 0.0, 5631.3, 1636, 9775, 8893.1, 9383.35, 9775.0, 0.9707795359673818, 42.46591653722939, 0.11565928065236385], "isController": false}, {"data": ["HTTP Request-Website-0", 50, 0, 0.0, 2187.24, 243, 4061, 3978.7, 4059.45, 4061.0, 1.136621959536258, 0.5339015259149806, 0.1354178506478745], "isController": false}, {"data": ["HTTP Request-Contact-0", 6, 0, 0.0, 2744.833333333333, 626, 4540, 4540.0, 4540.0, 4540.0, 0.12393109431156277, 0.0681378965795018, 0.01924320702689305], "isController": false}, {"data": ["88.202.218.154 TCP", 149, 0, 0.0, 64718.120805369115, 15000, 120000, 105000.0, 115000.0, 119500.0, 0.6528187310781148, 0.0, 0.0], "isController": false}, {"data": ["HTTP Request-About-1", 50, 0, 0.0, 6846.12, 1384, 12496, 10509.4, 11312.449999999999, 12496.0, 0.5456073155028862, 19.76760879409871, 0.08578396269137176], "isController": false}, {"data": ["HTTP Request-Contact-1", 6, 0, 0.0, 6735.666666666667, 2386, 12383, 12383.0, 12383.0, 12383.0, 0.11958384820823534, 4.292192077819189, 0.018568195180770918], "isController": false}, {"data": ["88.202.218.154 Network I\/O", 149, 0, 0.0, 2.6365999999999996E7, 0, 232803000, 6.0579E7, 7.7418E7, 2.228435E8, 6.396407351776471E-4, 0.0, 0.0], "isController": false}, {"data": ["HTTP Request-About-0", 50, 0, 0.0, 1991.8800000000003, 506, 4056, 3771.3999999999996, 3903.8499999999995, 4056.0, 0.5634564673533323, 0.31199200877865174, 0.0885903234803579], "isController": false}, {"data": ["HTTP Request-Store-Eyes&Brows", 50, 0, 0.0, 8702.02, 3910, 12510, 11448.5, 12325.15, 12510.0, 0.6221304234219661, 26.336652075116028, 0.2102120376015628], "isController": false}, {"data": ["HTTP Request-Website", 50, 0, 0.0, 7819.499999999999, 2141, 13012, 12362.1, 12909.0, 13012.0, 0.966146235894265, 42.717061357532074, 0.2302145327716803], "isController": false}, {"data": ["HTTP Request-Blog-0", 50, 0, 0.0, 1728.5999999999997, 388, 4559, 3508.399999999999, 4398.8, 4559.0, 0.5817741785348599, 0.33577005811924043, 0.0971517427045518], "isController": false}, {"data": ["88.202.218.154 CPU", 149, 0, 0.0, 39939.79865771811, 1745, 100000, 89775.0, 97740.0, 100000.0, 0.5906159450449701, 0.0, 0.0], "isController": false}, {"data": ["HTTP Request-Store-Lips", 50, 0, 0.0, 8468.68, 2666, 14533, 13758.3, 13841.15, 14533.0, 0.700142829137144, 38.053173003542724, 0.2365716981264178], "isController": false}, {"data": ["HTTP Request--Youtube-1", 20, 0, 0.0, 9397.750000000002, 3749, 16794, 16110.300000000001, 16761.399999999998, 16794.0, 0.30551142612733717, 49.639878406452404, 0.05012296834901626], "isController": false}, {"data": ["HTTP Request-Blog-1", 50, 0, 0.0, 6639.020000000001, 2626, 10855, 9871.9, 9970.449999999999, 10855.0, 0.5820654008684416, 31.409363140417458, 0.09720037455908546], "isController": false}, {"data": ["HTTP Request-Blog-Beauty", 44, 0, 0.0, 6191.477272727273, 1786, 13396, 11304.0, 13090.5, 13396.0, 0.5680204487361545, 20.239611438511787, 0.1930381993751775], "isController": false}, {"data": ["88.202.218.154 Memory", 149, 0, 0.0, 63532.75838926173, 52136, 68944, 68320.0, 68642.5, 68873.0, 0.6929587945307414, 0.0, 0.0], "isController": false}, {"data": ["HTTP Request-Store-Face", 50, 0, 0.0, 10605.699999999999, 4555, 16445, 14681.4, 15953.149999999998, 16445.0, 0.5568424803991447, 29.50014425700508, 0.18815185372861726], "isController": false}, {"data": ["HTTP Request--Youtube-0", 20, 0, 0.0, 2599.3, 118, 7017, 6693.500000000002, 7004.349999999999, 7017.0, 0.30749361950739523, 0.17560768426555148, 0.050448171950432025], "isController": false}, {"data": ["HTTP Request-About", 50, 0, 0.0, 8838.1, 5185, 13416, 12159.099999999999, 12500.6, 13416.0, 0.5285077056423483, 19.440722410576498, 0.16619089962581654], "isController": false}, {"data": ["HTTP Request-Store-Eyes&Brows-1", 50, 0, 0.0, 6788.02, 2205, 11164, 9770.8, 10711.7, 11164.0, 0.6301038411130154, 26.308066038033065, 0.10645309034428874], "isController": false}, {"data": ["HTTP Request-Store-Face-1", 50, 0, 0.0, 8672.78, 3363, 12992, 11727.199999999999, 12839.75, 12992.0, 0.5606323933396872, 29.375166437741772, 0.09471621489039636], "isController": false}, {"data": ["HTTP Request-Store-Eyes&Brows-0", 50, 0, 0.0, 1913.64, 578, 5132, 3146.4999999999995, 3833.2499999999977, 5132.0, 0.7225015895034969, 0.4198129353072077, 0.12206325682041502], "isController": false}, {"data": ["HTTP Request-Store-Face-0", 50, 0, 0.0, 1932.66, 555, 5167, 3830.5, 4675.449999999996, 5167.0, 0.6501950585175553, 0.3777988865409623, 0.10984740734720415], "isController": false}, {"data": ["HTTP Request-Blog-LifeStyle", 27, 0, 0.0, 5482.6296296296305, 766, 12161, 9378.399999999998, 12157.4, 12161.0, 0.3734543140889098, 12.980752190586184, 0.12691611455365293], "isController": false}, {"data": ["88.202.218.154 Disks I\/O", 149, 0, 0.0, 1.23803651501406432E17, 0, 9223372036854775807, 0.0, 0.0, 9.223372036854776E18, 0.9720835861403062, 0.0, 0.0], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2685, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
